const express = require("express");
const app = express();
const path = require("path");
const os = require("os");

// 정적 파일(HTML) 제공
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// 라우터 불러오기
const userRouter = require("./routes/user");
const commentRouter = require("./routes/comment");
const productRouter = require("./routes/product");
const reviewRouter = require("./routes/review");
const wishlistRouter = require("./routes/wishlist");

// 라우터 등록
app.use("/product", productRouter);
app.use("/user", userRouter);
app.use("/comment", commentRouter);
app.use("/review", reviewRouter);
app.use("/wishlist", wishlistRouter);

app.use(express.static(path.join(__dirname, "public")));

// 서버 실행
const PORT = 3000;
const HOST = '0.0.0.0'; // 모든 IP에서 접근 가능
app.listen(PORT, HOST, () => {
  // 로컬 IP 확인
  const nets = os.networkInterfaces();
  let localIp = "localhost";
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        localIp = net.address;
      }
    }
  }
  console.log(`서버 실행됨: http://${localIp}:${PORT}`);
});
