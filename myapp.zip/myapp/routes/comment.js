const express = require("express");
const router = express.Router();

// 댓글 관련 라우트를 여기에 추가합니다.

module.exports = router;