// routes/product.js
const express = require("express");
const router = express.Router();
console.log("✅ Product Router 모듈 로드 및 등록 시작."); 
const db = require("../db/db"); // db 연결 공통 모듈

// 상품 등록
router.post("/add", (req, res) => {
  const { title, description, price, image_url, category, seller_id } = req.body;

  if (!title || !price || !seller_id) {
    return res.status(400).send("필수 값이 누락되었습니다.");
  }

  const sql = `
    INSERT INTO product (title, price, description, image_url, category, seller_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [title, price, description || null, image_url || null, category || null, seller_id],
    (err, result) => {
      if (err) {
        console.error("상품 등록 오류:", err);
        return res.status(500).send("상품 등록 실패");
      }
      res.send({ message: "상품 등록 성공", productId: result.insertId });
    }
  );
});

module.exports = router;
